# Factory Game

First-person, low-poly factory-building game (Satisfactory/Industrialist-inspired),
built with TypeScript + Three.js, bundled by Vite into a **single self-contained
`dist/index.html`**.

## Stack

- **TypeScript** — typed source, split across multiple files under `src/`.
- **Three.js** — WebGL rendering.
- **Vite** + `vite-plugin-singlefile` — dev server for iteration, and a build
  that inlines all JS/CSS into one HTML file (no external script/link tags).

## Setup (in a GitHub Codespace)

```bash
npm install
```

## Dev loop (hot reload, multiple files, easiest for active development)

```bash
npm run dev
```

Then use the Codespace's forwarded-port preview (or `Ports` tab) to open it
in a browser tab.

## Production build (the actual deliverable: one HTML file)

```bash
npm run build
```

Output: `dist/index.html` — a single file, ~480KB, that runs standalone in
any browser with no server, no external requests, no dependencies. Double
click it or open it via `file://`.

## Project layout

```
src/
  main.ts                     entry point, wires everything together
  core/
    Engine.ts                 scene/camera/renderer/render-loop
  world/
    World.ts                  sky, lights, ground, placeholder props
  player/
    FirstPersonController.ts  pointer-lock mouse look + WASD + gravity/jump
  utils/
    constants.ts               grid sizes, player physics constants
```

## Current controls

- Click canvas to lock pointer / look around
- WASD to move, Shift to sprint, Space to jump

## Grid conventions (for the upcoming building system)

- `BUILD_GRID = 1m` — fine snap for placing machines/belts on a foundation
- `WORLD_GRID = 8m` — coarse snap for placing foundations, so distant
  factory sections line up without manual nudging
- `FLOOR_HEIGHT_STEP = 1m` — vertical snap between floors

These mirror Satisfactory's foundation snapping conventions and are defined
in `src/utils/constants.ts`, ready for the placement/building system.

## Roadmap (not yet built)

1. Build-mode raycasting + ghost/preview mesh for placing objects
2. Grid-snapped foundation placement
3. Machine placeholders (miners, smelters, constructors) with simple I/O ports
4. Conveyor belt segments connecting ports
5. Inventory/hotbar UI
6. Save/load (likely `localStorage` or exported JSON, since this is a
   single static HTML file with no backend)
