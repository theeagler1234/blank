import * as THREE from "three";

export type UpdateFn = (deltaSeconds: number) => void;

/**
 * Owns the Three.js scene, camera, renderer, and the main loop.
 * Everything else (world, player, future factory systems) plugs into this
 * via `addUpdateCallback` and by adding objects to `scene`.
 */
export class Engine {
  readonly scene: THREE.Scene;
  readonly camera: THREE.PerspectiveCamera;
  readonly renderer: THREE.WebGLRenderer;

  private clock = new THREE.Clock();
  private updateCallbacks: UpdateFn[] = [];
  private fpsEl = document.getElementById("fps");
  private frameAccum = 0;
  private frameCount = 0;

  constructor(private container: HTMLElement) {
    this.scene = new THREE.Scene();

    this.camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    window.addEventListener("resize", () => this.onResize());
  }

  addUpdateCallback(fn: UpdateFn) {
    this.updateCallbacks.push(fn);
  }

  private onResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  start() {
    this.renderer.setAnimationLoop(() => this.tick());
  }

  private tick() {
    const delta = Math.min(this.clock.getDelta(), 0.1); // clamp to avoid huge steps on tab-switch

    for (const cb of this.updateCallbacks) cb(delta);

    this.renderer.render(this.scene, this.camera);

    this.reportFps(delta);
  }

  private reportFps(delta: number) {
    this.frameAccum += delta;
    this.frameCount++;
    if (this.frameAccum >= 0.5 && this.fpsEl) {
      const fps = Math.round(this.frameCount / this.frameAccum);
      this.fpsEl.textContent = `${fps} fps`;
      this.frameAccum = 0;
      this.frameCount = 0;
    }
  }
}
