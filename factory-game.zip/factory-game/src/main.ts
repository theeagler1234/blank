import { Engine } from "./core/Engine";
import { World } from "./world/World";
import { FirstPersonController } from "./player/FirstPersonController";

const engine = new Engine(document.body);
new World(engine.scene);

const player = new FirstPersonController(engine.camera, engine.renderer.domElement);
engine.scene.add(player.object);

engine.addUpdateCallback((delta) => player.update(delta));

engine.start();
