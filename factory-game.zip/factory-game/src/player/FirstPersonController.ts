import * as THREE from "three";
import { PLAYER } from "../utils/constants";

const PI_2 = Math.PI / 2;

/**
 * A from-scratch first-person controller (not Three's PointerLockControls)
 * so we have full control over movement for later factory-building needs
 * (grid snapping, vehicle mounting, build-mode raycasts, etc).
 */
export class FirstPersonController {
  readonly object = new THREE.Object3D(); // yaw pivot, holds position
  private pitchObject = new THREE.Object3D(); // pitch pivot, holds camera

  private velocity = new THREE.Vector3();
  private verticalVelocity = 0;
  private onGround = true;

  private euler = new THREE.Euler(0, 0, 0, "YXZ");

  private keys: Record<string, boolean> = {};
  private isLocked = false;

  constructor(
    private camera: THREE.PerspectiveCamera,
    private domElement: HTMLElement
  ) {
    this.object.position.set(0, PLAYER.eyeHeight, 8);
    this.pitchObject.add(this.camera);
    this.object.add(this.pitchObject);

    this.bindPointerLock();
    this.bindKeyboard();
  }

  private bindPointerLock() {
    this.domElement.addEventListener("click", () => {
      this.domElement.requestPointerLock();
    });

    document.addEventListener("pointerlockchange", () => {
      this.isLocked = document.pointerLockElement === this.domElement;
    });

    document.addEventListener("mousemove", (e) => {
      if (!this.isLocked) return;

      this.euler.setFromQuaternion(this.object.quaternion);
      // Yaw goes on the outer object, pitch on the inner pivot.
      const yaw = this.euler.y - e.movementX * 0.0022;
      let pitch = this.pitchObject.rotation.x - e.movementY * 0.0022;
      pitch = Math.max(-PI_2, Math.min(PI_2, pitch));

      this.object.rotation.y = yaw;
      this.pitchObject.rotation.x = pitch;
    });
  }

  private bindKeyboard() {
    window.addEventListener("keydown", (e) => (this.keys[e.code] = true));
    window.addEventListener("keyup", (e) => (this.keys[e.code] = false));
  }

  update(delta: number) {
    this.applyMovement(delta);
    this.applyGravity(delta);
  }

  private applyMovement(delta: number) {
    const speed = this.keys["ShiftLeft"] || this.keys["ShiftRight"]
      ? PLAYER.sprintSpeed
      : PLAYER.walkSpeed;

    const forward = (this.keys["KeyW"] ? 1 : 0) - (this.keys["KeyS"] ? 1 : 0);
    const strafe = (this.keys["KeyD"] ? 1 : 0) - (this.keys["KeyA"] ? 1 : 0);

    const moveDir = new THREE.Vector3(strafe, 0, -forward);
    if (moveDir.lengthSq() > 0) moveDir.normalize();

    // Rotate move direction by yaw only (no flying by looking up/down).
    moveDir.applyEuler(new THREE.Euler(0, this.object.rotation.y, 0));

    this.velocity.x = moveDir.x * speed;
    this.velocity.z = moveDir.z * speed;

    this.object.position.x += this.velocity.x * delta;
    this.object.position.z += this.velocity.z * delta;

    if (this.keys["Space"] && this.onGround) {
      this.verticalVelocity = PLAYER.jumpVelocity;
      this.onGround = false;
    }
  }

  private applyGravity(delta: number) {
    this.verticalVelocity += PLAYER.gravity * delta;
    this.object.position.y += this.verticalVelocity * delta;

    // Flat-ground collision for now; will become a proper raycast against
    // foundations/terrain once buildable geometry exists.
    if (this.object.position.y <= PLAYER.eyeHeight) {
      this.object.position.y = PLAYER.eyeHeight;
      this.verticalVelocity = 0;
      this.onGround = true;
    }
  }
}
