/**
 * Grid conventions (loosely inspired by Satisfactory's foundation system):
 * - BUILD_GRID: fine snap step for placing machines/belts on a foundation (1m).
 * - WORLD_GRID: coarse snap step for placing foundations themselves (8m),
 *   so distant factory sections align without manual nudging.
 * These aren't used by the renderer yet, but the whole building system will
 * key off them later, so they live here from day one.
 */
export const BUILD_GRID = 1; // meters
export const WORLD_GRID = 8; // meters
export const FLOOR_HEIGHT_STEP = 1; // meters, vertical snap between floors

export const PLAYER = {
  eyeHeight: 1.8, // meters
  radius: 0.35,
  walkSpeed: 4.5, // m/s
  sprintSpeed: 7.5, // m/s
  jumpVelocity: 6.0,
  gravity: -18,
};

export const WORLD = {
  groundSize: 400, // meters, one side of the ground plane
  fogNear: 40,
  fogFar: 220,
};
