import * as THREE from "three";
import { WORLD, BUILD_GRID } from "../utils/constants";

/**
 * Builds the static parts of the scene: sky, lights, ground, and a handful
 * of placeholder low-poly props so there's something to walk around and
 * judge scale against. Every mesh uses flat shading + simple geometry to
 * keep the low-poly industrial look and stay cheap to render.
 */
export class World {
  readonly group = new THREE.Group();

  constructor(scene: THREE.Scene) {
    this.setupSky(scene);
    this.setupLights(scene);
    this.setupGround();
    this.setupGridHelper();
    this.setupPlaceholderProps();

    scene.add(this.group);
  }

  private setupSky(scene: THREE.Scene) {
    scene.background = new THREE.Color(0x8fb8d8);
    scene.fog = new THREE.Fog(0x8fb8d8, WORLD.fogNear, WORLD.fogFar);
  }

  private setupLights(scene: THREE.Scene) {
    const hemi = new THREE.HemisphereLight(0xbfd9ff, 0x3a3a2f, 0.9);
    scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xfff2d6, 1.6);
    sun.position.set(60, 90, 40);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -100;
    sun.shadow.camera.right = 100;
    sun.shadow.camera.top = 100;
    sun.shadow.camera.bottom = -100;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 300;
    sun.shadow.bias = -0.0015;
    scene.add(sun);
  }

  private setupGround() {
    const geo = new THREE.PlaneGeometry(WORLD.groundSize, WORLD.groundSize, 1, 1);
    const mat = new THREE.MeshStandardMaterial({
      color: 0x5c7a4a,
      flatShading: true,
      roughness: 1,
    });
    const ground = new THREE.Mesh(geo, mat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.group.add(ground);
  }

  /** Faint grid to visualize the future build grid, purely cosmetic for now. */
  private setupGridHelper() {
    const divisions = WORLD.groundSize / BUILD_GRID;
    const grid = new THREE.GridHelper(WORLD.groundSize, divisions, 0x222222, 0x334433);
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = 0.12;
    grid.position.y = 0.01;
    this.group.add(grid);
  }

  private lowPolyMaterial(hex: number) {
    return new THREE.MeshStandardMaterial({ color: hex, flatShading: true, roughness: 0.8, metalness: 0.1 });
  }

  /** A few blocky low-poly "factory" shapes so there's scale reference while walking. */
  private setupPlaceholderProps() {
    const crateMat = this.lowPolyMaterial(0xc98a3a);
    const tankMat = this.lowPolyMaterial(0x9aa5ad);
    const pillarMat = this.lowPolyMaterial(0x4a4f57);

    // Crates
    const crateGeo = new THREE.BoxGeometry(1, 1, 1);
    for (const [x, z] of [[4, -6], [5.2, -6], [4, -4.8]] as const) {
      const crate = new THREE.Mesh(crateGeo, crateMat);
      crate.position.set(x, 0.5, z);
      crate.castShadow = true;
      crate.receiveShadow = true;
      this.group.add(crate);
    }

    // Storage tank (low-poly cylinder)
    const tankGeo = new THREE.CylinderGeometry(1.5, 1.5, 3, 8);
    const tank = new THREE.Mesh(tankGeo, tankMat);
    tank.position.set(-8, 1.5, -10);
    tank.castShadow = true;
    tank.receiveShadow = true;
    this.group.add(tank);

    // Support pillars, arranged in a rough rectangle to suggest a structure footprint
    const pillarGeo = new THREE.BoxGeometry(0.4, 4, 0.4);
    const pillarPositions: [number, number][] = [
      [-4, -20], [4, -20], [-4, -28], [4, -28],
    ];
    for (const [x, z] of pillarPositions) {
      const pillar = new THREE.Mesh(pillarGeo, pillarMat);
      pillar.position.set(x, 2, z);
      pillar.castShadow = true;
      pillar.receiveShadow = true;
      this.group.add(pillar);
    }
  }
}
