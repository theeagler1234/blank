import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

// Multiple TS/HTML/CSS source files compile down into ONE dist/index.html
// (all JS + CSS inlined, no external requests) via vite-plugin-singlefile.
export default defineConfig({
  plugins: [viteSingleFile()],
  build: {
    target: "esnext",
    assetsInlineLimit: 100_000_000, // inline everything (textures etc. later)
    cssCodeSplit: false,
    outDir: "dist",
  },
});
